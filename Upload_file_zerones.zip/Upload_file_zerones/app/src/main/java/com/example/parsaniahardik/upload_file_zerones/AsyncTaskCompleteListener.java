package com.example.parsaniahardik.upload_file_zerones;

/**
 * Created by Parsania Hardik on 19/01/2016.
 */
public interface AsyncTaskCompleteListener {
    void onTaskCompleted(String response, int serviceCode);
}

